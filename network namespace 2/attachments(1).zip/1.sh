
sudo ip netns add ak

sudo ip link add eth0 type veth peer name eth1

sudo ip link set eth0 netns ak

sudo ip netns exec ak ip link set lo up

sudo ip netns exec ak ip link set eth0 up

sudo ip netns exec ak ip address add 10.0.0.1/24 dev eth0

sudo ping -c 5 10.0.0.3

sudo ip netns delete ak

sudo ip link delete eth1
